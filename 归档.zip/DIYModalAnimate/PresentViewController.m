//
//  PresentViewController.m
//  UIViewControllerAnimatedTransitioningDemo
//
//  Created by Rochang on 16/9/20.
//  Copyright © 2016年 Rochang. All rights reserved.
//

#import "PresentViewController.h"
#import "DismisslAnimate.h"

@interface PresentViewController ()<UIViewControllerTransitioningDelegate>

@property (strong, nonatomic) UIButton *centreButton;
@property (strong, nonatomic) UIImageView *imageView;
/** 是否正在交互 */
@property (assign, nonatomic) BOOL isInteraction;
/** 是否完成交互 */
@property (assign, nonatomic) BOOL isFinishInteraction;

// dismiss动画
@property (strong, nonatomic) DismisslAnimate *dismiss;
// 手势交互过渡
@property (strong, nonatomic) UIPercentDrivenInteractiveTransition *interactionTransition;

@end

@implementation PresentViewController
#pragma mark - life cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.imageView];
    [self.view addSubview:self.centreButton];
    
    self.transitioningDelegate = self;
    // 添加手势交互
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePanGesture:)];
    [self.view addGestureRecognizer:pan];
}
- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    [self.centreButton sizeToFit];
    self.centreButton.center = self.view.center;
}

#pragma mark - UIViewControllerTransitioningDelegate 
// dismiss 动画
- (id<UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed {
    return self.dismiss;
}

// dismiss 交互动画
- (nullable id <UIViewControllerInteractiveTransitioning>)interactionControllerForDismissal:(id <UIViewControllerAnimatedTransitioning>)animator {
    return self.isInteraction ? self.interactionTransition : nil;
}


#pragma mark - response event
- (void)handButtonClick:(UIButton *)button {
    if (self.centreButtonClickBlock) {
        self.centreButtonClickBlock(button);
    }
}

- (void)handlePanGesture:(UIPanGestureRecognizer *)pan {
    CGFloat height = [UIScreen mainScreen].bounds.size.height;
    CGPoint point = [pan translationInView:pan.view.superview];
    CGFloat percent = point.y / height;
    static CGFloat beginTime;
    switch (pan.state) {
        case UIGestureRecognizerStateBegan:{
            self.isInteraction = YES;
            beginTime = CACurrentMediaTime();
            [self dismissViewControllerAnimated:YES completion:nil];
        }
            break;
        case UIGestureRecognizerStateChanged:{
            // 计算滑动速度
            CGFloat speen = point.y / (CACurrentMediaTime() - beginTime);
            [self.interactionTransition updateInteractiveTransition:percent];
            self.isFinishInteraction = (speen > 600 || percent > 0.5);
        }
            break;
        case UIGestureRecognizerStateCancelled:{
            self.isInteraction = NO;
            [self.interactionTransition cancelInteractiveTransition];
        }
            break;
        case UIGestureRecognizerStateEnded:{
            self.isInteraction = NO;
            if (self.isFinishInteraction) {
                [self.interactionTransition finishInteractiveTransition];
            } else {
                [self.interactionTransition cancelInteractiveTransition];
            }
        }
            break;
        default:
            break;
    }
}

#pragma mark - getter
- (UIButton *)centreButton {
    if (!_centreButton) {
        _centreButton = [[UIButton alloc] init];
        _centreButton.backgroundColor = [UIColor redColor];
        [_centreButton setTitle:@" dismiss me ⬇️ " forState:UIControlStateNormal];
        [_centreButton setTitleColor:[UIColor greenColor] forState:UIControlStateNormal];
        [_centreButton addTarget:self action:@selector(handButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _centreButton;
}

- (DismisslAnimate *)dismiss  {
    if (!_dismiss) {
        _dismiss = [[DismisslAnimate alloc] init];
    }
    return _dismiss;
}

- (UIPercentDrivenInteractiveTransition *)interactionTransition  {
    if (!_interactionTransition) {
        _interactionTransition = [[UIPercentDrivenInteractiveTransition alloc] init];
    }
    return _interactionTransition;
}

- (UIImageView *)imageView  {
    if (!_imageView) {
        _imageView = [[UIImageView alloc] initWithFrame:self.view.bounds];
        _imageView.image = [UIImage imageNamed:@"2"];
        _imageView.userInteractionEnabled = YES;
    }
    return _imageView;
}
@end
