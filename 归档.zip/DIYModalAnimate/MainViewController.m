//
//  MainViewController.m
//  UIViewControllerAnimatedTransitioningDemo
//
//  Created by Rochang on 16/9/20.
//  Copyright © 2016年 Rochang. All rights reserved.
//

#import "MainViewController.h"
#import "PresentViewController.h"
#import "PresentAnimate.h"

@interface MainViewController ()<UIViewControllerTransitioningDelegate>

@property (strong, nonatomic) UIButton *centreButton;
@property (strong, nonatomic) UIImageView *imageView;
// persent动画
@property (strong, nonatomic) PresentAnimate *presentAnimate;

@end

@implementation MainViewController
#pragma mark - life cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"modal Interaction";
    [self.view addSubview:self.imageView];
    [self.view addSubview:self.centreButton];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    [self.centreButton sizeToFit];
    self.centreButton.center = self.view.center;
}

#pragma mark - response event
- (void)handButtonClick:(UIButton *)button {
    __weak typeof(self) weakself = self;
    PresentViewController *presentVc = [[PresentViewController alloc] init];
    [presentVc setCentreButtonClickBlock:^(UIButton *button) {
        [weakself dismissViewControllerAnimated:YES completion:nil];
    }];
    [self presentViewController:presentVc animated:YES completion:nil];
}

#pragma mark - getter
- (UIButton *)centreButton {
    if (!_centreButton) {
        _centreButton = [[UIButton alloc] init];
        _centreButton.backgroundColor = [UIColor purpleColor];
        [_centreButton setTitle:@" modal me " forState:UIControlStateNormal];
        [_centreButton setTitleColor:[UIColor greenColor] forState:UIControlStateNormal];
        [_centreButton addTarget:self action:@selector(handButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _centreButton;
}

- (PresentAnimate *)presentAnimate {
    if (!_presentAnimate) {
        _presentAnimate = [[PresentAnimate alloc] init];
    }
    return _presentAnimate;
}

- (UIImageView *)imageView  {
    if (!_imageView) {
        _imageView = [[UIImageView alloc] initWithFrame:self.view.bounds];
        _imageView.image = [UIImage imageNamed:@"1"];
        _imageView.userInteractionEnabled = YES;
    }
    return _imageView;
}
@end
