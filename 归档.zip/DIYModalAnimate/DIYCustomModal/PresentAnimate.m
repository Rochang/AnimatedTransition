//
//  PresentAnimate.m
//  UIViewControllerAnimatedTransitioningDemo
//
//  Created by Rochang on 16/9/20.
//  Copyright © 2016年 Rochang. All rights reserved.
//

#import "PresentAnimate.h"


@implementation PresentAnimate
/** 动画持续时间 */
- (NSTimeInterval)transitionDuration:(id<UIViewControllerContextTransitioning>)transitionContext {
    return 0.4;
}

- (void)animateTransition:(id<UIViewControllerContextTransitioning>)transitionContext {
    // 获取toVc
    UIViewController *toVc = [transitionContext viewControllerForKey:UITransitionContextToViewControllerKey];
    
    // 设置frame
    CGRect finalFrame = [transitionContext finalFrameForViewController:toVc];
    toVc.view.frame = CGRectOffset(finalFrame, 0, finalFrame.size.height);
    
    // 获取上下文容量
    UIView *contrainerView = [transitionContext containerView];
    [contrainerView addSubview:toVc.view];
    
    // 动画
    NSTimeInterval duration = [self transitionDuration:transitionContext];
    [UIView animateWithDuration:duration
                     animations:^{
                         toVc.view.frame = finalFrame;
                        } completion:^(BOOL finished) {
                            // context完毕
                            BOOL isComplete = [transitionContext transitionWasCancelled];
                            [transitionContext completeTransition:!isComplete];
                        }];
}
@end
