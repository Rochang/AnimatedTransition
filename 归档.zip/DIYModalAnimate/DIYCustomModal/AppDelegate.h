//
//  AppDelegate.h
//  DIYCustomModal
//
//  Created by Rochang on 16/9/22.
//  Copyright © 2016年 Rochang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

