//
//  DismisslAnimate.m
//  UIViewControllerAnimatedTransitioningDemo
//
//  Created by Rochang on 16/9/20.
//  Copyright © 2016年 Rochang. All rights reserved.
//

#import "DismisslAnimate.h"

@implementation DismisslAnimate

// 动画时间
- (NSTimeInterval)transitionDuration:(id<UIViewControllerContextTransitioning>)transitionContext {
    return 0.4;
}

// 动画效果
- (void)animateTransition:(id<UIViewControllerContextTransitioning>)transitionContext {
    // 获取toVC
    UIViewController *toVc = [transitionContext viewControllerForKey:UITransitionContextToViewControllerKey];
    UIViewController *fromVc = [transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey];
    
    // 设置toVC.frame
    CGRect toViewFinalFrame = [transitionContext finalFrameForViewController:toVc];
    toVc.view.frame = CGRectOffset(toViewFinalFrame, 0, -[UIScreen mainScreen].bounds.size.height);
    
    
    // 添加到trainerVeiw
    UIView *containerView = [transitionContext containerView];
    [containerView addSubview:toVc.view];
    
    NSTimeInterval duration = [self transitionDuration:transitionContext];
    [UIView animateWithDuration:duration
                     animations:^{
                         toVc.view.frame = toViewFinalFrame;
                         fromVc.view.alpha = 0.0;
                     } completion:^(BOOL finished) {
                         fromVc.view.alpha = 1.0;
                          // 完毕
                         BOOL isComplete = [transitionContext transitionWasCancelled];
                         [transitionContext completeTransition:!isComplete];
                     }];
}
@end
