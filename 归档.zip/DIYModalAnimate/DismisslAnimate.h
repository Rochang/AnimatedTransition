//
//  DismisslAnimate.h
//  UIViewControllerAnimatedTransitioningDemo
//
//  Created by Rochang on 16/9/20.
//  Copyright © 2016年 Rochang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DismisslAnimate : NSObject<UIViewControllerAnimatedTransitioning>

@end
