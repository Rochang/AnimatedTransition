//
//  MainViewController.m
//  DIYPushAnimate
//
//  Created by Rochang on 16/9/21.
//  Copyright © 2016年 Rochang. All rights reserved.
//

#import "MainViewController.h"
#import "LCCollecionViewCell.h"
#import "UIView+LayoutMethods.h"
#import "LCDescribeViewController.h"
#import "LCPushAnimate.h"

@interface MainViewController ()<UICollectionViewDataSource, UICollectionViewDelegate, UINavigationControllerDelegate>

@property (strong, nonatomic) NSArray *dataSource;
@property (strong, nonatomic) LCPushAnimate *pushAnimate;

@end

@implementation MainViewController
#pragma mark - life cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"🐶";
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.collectionView];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.navigationController.delegate = self;
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    if (self.navigationController.delegate) {
        self.navigationController.delegate = nil;
    }
}

#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.dataSource.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    LCCollecionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:[LCCollecionViewCell identify] forIndexPath:indexPath];
    // comfig cell
    cell.model = self.dataSource[indexPath.row];
    return cell;
}

#pragma mark - UICollectionViewDelegate
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    LCDescribeViewController *describeVc = [[LCDescribeViewController alloc] init];
    describeVc.model = self.dataSource[indexPath.row];
    [self.navigationController pushViewController:describeVc animated:YES];
}

#pragma mark - UINavigationControllerDelegate
// 设置自定义转场动画
- (id<UIViewControllerAnimatedTransitioning>)navigationController:(UINavigationController *)navigationController animationControllerForOperation:(UINavigationControllerOperation)operation fromViewController:(UIViewController *)fromVC toViewController:(UIViewController *)toVC {
    return self.pushAnimate;
}

#pragma mark - getter

- (UICollectionView *)collectionView {
    if (!_collectionView) {
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
        layout.minimumInteritemSpacing = 0;
        layout.minimumLineSpacing = 0;
        layout.scrollDirection = UICollectionViewScrollDirectionVertical;
        layout.itemSize = CGSizeMake(self.view.width / 2, self.view.width / 2 + 21);
        _collectionView = [[UICollectionView alloc] initWithFrame:self.view.bounds collectionViewLayout:layout];
        _collectionView.dataSource = self;
        _collectionView.delegate = self;
        _collectionView.backgroundColor = [UIColor whiteColor];
        [_collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([LCCollecionViewCell class]) bundle:nil] forCellWithReuseIdentifier:[LCCollecionViewCell identify]];
    }
    return _collectionView;
}

- (NSArray *)dataSource {
    if (!_dataSource) {
        _dataSource = [LCCollectionViewCellModel getLCCollectionViewCellDataSourse];
    }
    return _dataSource;
}

- (LCPushAnimate *)pushAnimate  {
    if (!_pushAnimate) {
        _pushAnimate = [[LCPushAnimate alloc] init];
    }
    return _pushAnimate;
}
@end
