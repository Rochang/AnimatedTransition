//
//  AppDelegate.h
//  DIYPushAnimate
//
//  Created by Rochang on 16/9/21.
//  Copyright © 2016年 Rochang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

