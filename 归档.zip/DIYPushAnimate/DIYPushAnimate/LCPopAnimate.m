//
//  LCPopAnimate.m
//  DIYPushAnimate
//
//  Created by Rochang on 16/9/21.
//  Copyright © 2016年 Rochang. All rights reserved.
//

#import "LCPopAnimate.h"
#import "MainViewController.h"
#import "LCDescribeViewController.h"
#import "LCCollecionViewCell.h"

@implementation LCPopAnimate

- (NSTimeInterval)transitionDuration:(id<UIViewControllerContextTransitioning>)transitionContext {
    return 0.3;
}

- (void)animateTransition:(id<UIViewControllerContextTransitioning>)transitionContext {
    
    LCDescribeViewController *fromVc = (LCDescribeViewController *)[transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey];
    MainViewController *toVc = (MainViewController *)[transitionContext viewControllerForKey:UITransitionContextToViewControllerKey];
    UIView *contrainerViw = [transitionContext containerView];
    
    // 获取选中的cell
    NSIndexPath *selectIndexPath = [toVc.collectionView indexPathsForSelectedItems].firstObject;
    LCCollecionViewCell *selectCell = (LCCollecionViewCell *)[toVc.collectionView cellForItemAtIndexPath:selectIndexPath];
    // 截图fromVc中的imageView
    UIView *fromViewImage = [fromVc.imageView snapshotViewAfterScreenUpdates:NO];
    fromViewImage.frame = [contrainerViw convertRect:fromVc.imageView.frame fromView:fromVc.imageView.superview];
    CGRect fromViewImageFinalFrame = [contrainerViw convertRect:selectCell.imageView.frame fromView:selectCell.imageView.superview];
    fromVc.imageView.hidden = YES;
    
    // 设置toVc
    toVc.view.frame = [transitionContext finalFrameForViewController:toVc];
    toVc.view.alpha = 0.0;
    selectCell.imageView.hidden = YES;
    
    [contrainerViw addSubview:toVc.view];
    [contrainerViw addSubview:fromViewImage];
    
    NSTimeInterval duration = [self transitionDuration:transitionContext];
    [UIView animateWithDuration:duration animations:^{
        fromViewImage.frame = fromViewImageFinalFrame;
        toVc.view.alpha = 1.0;
    } completion:^(BOOL finished) {
        // 复原
        selectCell.imageView.hidden = NO;
        fromVc.imageView.hidden = NO;
        [fromViewImage removeFromSuperview];
        [transitionContext completeTransition:![transitionContext transitionWasCancelled]];
    }];
}

@end
