//
//  LCCollecionViewCell.m
//  DIYPushAnimate
//
//  Created by Rochang on 16/9/21.
//  Copyright © 2016年 Rochang. All rights reserved.
//

#import "LCCollecionViewCell.h"

@interface LCCollecionViewCell ()

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@end

@implementation LCCollecionViewCell

- (void)setModel:(LCCollectionViewCellModel *)model {
    _model = model;
    self.imageView.image = [UIImage imageNamed:model.image];
    self.titleLabel.text = model.title;
}

+ (NSString *)identify {
    return @"LCCollecionViewCell";
}

@end
