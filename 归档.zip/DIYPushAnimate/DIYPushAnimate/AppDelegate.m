//
//  AppDelegate.m
//  DIYPushAnimate
//
//  Created by Rochang on 16/9/21.
//  Copyright © 2016年 Rochang. All rights reserved.
//

#import "AppDelegate.h"
#import "MainViewController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    MainViewController *mainVc = [[MainViewController alloc] init];
    self.window.rootViewController = [[UINavigationController alloc] initWithRootViewController:mainVc];
    [self.window makeKeyAndVisible];
    return YES;
}

@end
