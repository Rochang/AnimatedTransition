//
//  LCDescribeViewController.h
//  DIYPushAnimate
//
//  Created by Rochang on 16/9/21.
//  Copyright © 2016年 Rochang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LCCollectionViewCellModel.h"

@interface LCDescribeViewController : UIViewController

@property (strong, nonatomic) UIImageView *imageView;
@property (strong, nonatomic) LCCollectionViewCellModel *model;

@end
