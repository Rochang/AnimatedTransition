//
//  LCLabel.m
//  LabelPropertyDemo
//
//  Created by Rochang on 16/9/18.
//  Copyright © 2016年 Rochang. All rights reserved.
//

#import "LCLabel.h"

#define ISNEEDTOPLEFTSHOW

@interface LCLabel ()

@property(nonatomic, strong) NSMutableAttributedString *attributedString;

@end

@implementation LCLabel

- (void)setupAttributedStringWhitDict:(NSDictionary *)dict rang:(NSRange)rang {
    [self.attributedString addAttributes:dict range:rang];
    self.attributedText = self.attributedString;
}

#pragma mark - setter
- (void)setLineHeight:(CGFloat)lineHeight {
    _lineHeight = lineHeight;
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineSpacing = lineHeight;
    [self.attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, self.text.length)];
    self.attributedText = self.attributedString;
}

- (void)setFontSpacing:(CGFloat)fontSpacing {
    _fontSpacing = fontSpacing;
    [self.attributedString addAttribute:NSKernAttributeName value:@(fontSpacing) range:NSMakeRange(0, self.text.length)];
    self.attributedText = self.attributedString;
}

#pragma mark - getter
- (NSMutableAttributedString *)attributedString {
    if (!_attributedString) {
        _attributedString = [[NSMutableAttributedString alloc] initWithString:self.text];
    }
    return _attributedString;
}

#ifdef ISNEEDTOPLEFTSHOW
/** 当label宽高设置一定尺寸,文字以左上角显示,开发使用时可以另外创建重写 */
- (CGRect)textRectForBounds:(CGRect)bounds limitedToNumberOfLines:(NSInteger)numberOfLines {
    CGRect textRect = [super textRectForBounds:bounds limitedToNumberOfLines:numberOfLines];
    textRect.origin.y = bounds.origin.y;
    return textRect;
}

- (void)drawTextInRect:(CGRect)requestedRect {
    CGRect actualRect = [self textRectForBounds:requestedRect limitedToNumberOfLines:self.numberOfLines];
    [super drawTextInRect:actualRect];
}
#endif
@end
