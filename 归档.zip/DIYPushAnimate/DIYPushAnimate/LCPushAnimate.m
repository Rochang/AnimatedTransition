//
//  LCPushAnimate.m
//  DIYPushAnimate
//
//  Created by Rochang on 16/9/21.
//  Copyright © 2016年 Rochang. All rights reserved.
//

#import "LCPushAnimate.h"
#import "MainViewController.h"
#import "LCDescribeViewController.h"
#import "LCCollecionViewCell.h"

@implementation LCPushAnimate

- (NSTimeInterval)transitionDuration:(id<UIViewControllerContextTransitioning>)transitionContext {
    return 0.3;
}

- (void)animateTransition:(id<UIViewControllerContextTransitioning>)transitionContext {
    
    LCDescribeViewController *toVc = (LCDescribeViewController *)[transitionContext viewControllerForKey:UITransitionContextToViewControllerKey];
    MainViewController *fromVc = (MainViewController *)[transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey];
    UIView *contrainerViw = [transitionContext containerView];
    
    // 设置选中的cell
    NSIndexPath *selectIndexPath = [fromVc.collectionView indexPathsForSelectedItems].firstObject;
    LCCollecionViewCell *selectCell = (LCCollecionViewCell *)[fromVc.collectionView cellForItemAtIndexPath:selectIndexPath];
    // 截图cell中的imageView
    UIView *selectCellImage = [selectCell.imageView snapshotViewAfterScreenUpdates:NO];
    selectCellImage.frame = [contrainerViw convertRect:selectCell.imageView.frame fromView:selectCell.imageView.superview];
    CGRect selectCellFinalFrame = [contrainerViw convertRect:toVc.imageView.frame fromView:toVc.view];
    selectCell.imageView.hidden = YES;
    
    // 设置toVc
    toVc.view.frame = [transitionContext finalFrameForViewController:toVc];
    toVc.view.alpha = 0.0;
    toVc.imageView.hidden = YES;
    
    [contrainerViw addSubview:toVc.view];
    [contrainerViw addSubview:selectCellImage];
    
    NSTimeInterval duration = [self transitionDuration:transitionContext];
    [UIView animateWithDuration:duration animations:^{
        selectCellImage.frame = selectCellFinalFrame;
        toVc.view.alpha = 1.0;
    } completion:^(BOOL finished) {
        // 复原
        selectCell.imageView.hidden = NO;
        toVc.imageView.hidden = NO;
        [selectCellImage removeFromSuperview];
        [transitionContext completeTransition:![transitionContext transitionWasCancelled]];
    }];
}

@end
