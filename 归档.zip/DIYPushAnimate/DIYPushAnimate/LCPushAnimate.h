//
//  LCPushAnimate.h
//  DIYPushAnimate
//
//  Created by Rochang on 16/9/21.
//  Copyright © 2016年 Rochang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface LCPushAnimate : NSObject<UIViewControllerAnimatedTransitioning>

@end
