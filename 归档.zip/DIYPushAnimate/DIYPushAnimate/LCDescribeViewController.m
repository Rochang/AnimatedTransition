//
//  LCDescribeViewController.m
//  DIYPushAnimate
//
//  Created by Rochang on 16/9/21.
//  Copyright © 2016年 Rochang. All rights reserved.
//

#import "LCDescribeViewController.h"
#import "LCPopAnimate.h"
#import "LCLabel.h"
#import "UIView+LayoutMethods.h"

@interface LCDescribeViewController ()<UINavigationControllerDelegate>

@property (strong, nonatomic) LCLabel *descirbeLabel;

@property (strong, nonatomic) LCPopAnimate *popAnimate;
/** 手势交互进度 */
@property (strong, nonatomic) UIPercentDrivenInteractiveTransition *popInteraction;
@property (assign, nonatomic) BOOL isInteraction;
@property (assign, nonatomic) BOOL isFinishInteraction;

@end

@implementation LCDescribeViewController
#pragma mark - life cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.imageView];
    [self.view addSubview:self.descirbeLabel];
    
    self.imageView.image = [UIImage imageNamed:self.model.image];
    self.descirbeLabel.text = _model.describeText;
    self.descirbeLabel.lineHeight = 30;
    
    self.descirbeLabel.width = self.view.width - 20;
    [self.descirbeLabel sizeToFit];
    self.descirbeLabel.centerX = self.view.width / 2;
    self.descirbeLabel.y = _imageView.bottom + 20;
    

    // 恢复侧滑手势
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handPanGesture:)];
    [self.view addGestureRecognizer:pan];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.navigationController.delegate = self;
}

- (void)viewWillDisappear:(BOOL)animated {
    if (self.navigationController.delegate == self) {
        self.navigationController.delegate = nil;
    }
}

#pragma mark - UINavigationControllerDelegate 
// pop
- (id<UIViewControllerAnimatedTransitioning>)navigationController:(UINavigationController *)navigationController animationControllerForOperation:(UINavigationControllerOperation)operation fromViewController:(UIViewController *)fromVC toViewController:(UIViewController *)toVC {
    return self.popAnimate;
}

// 手势交互
- (id<UIViewControllerInteractiveTransitioning>)navigationController:(UINavigationController *)navigationController interactionControllerForAnimationController:(id<UIViewControllerAnimatedTransitioning>)animationController {
    return self.isInteraction ? self.popInteraction : nil;
}

#pragma mark - response event
- (void)handPanGesture:(UIPanGestureRecognizer *)pan {
    CGPoint point = [pan translationInView:pan.view.superview];
    // 把percent限制在0.0到0.1
    static CGFloat beginTime;
    CGFloat percent = MIN(1.0, MAX(0.0, point.x / self.view.frame.size.width) * 1.0);
    switch (pan.state) {
        case UIGestureRecognizerStateBegan:{
            beginTime = CACurrentMediaTime();
            self.isInteraction = YES;
            [self.navigationController popViewControllerAnimated:YES];
        }
            break;
        case UIGestureRecognizerStateChanged:{
            CGFloat speen = point.x / (CACurrentMediaTime() - beginTime);
            self.isFinishInteraction = (speen > 600 || percent > 0.5);
            [self.popInteraction updateInteractiveTransition:percent];
        }
            break;
        case UIGestureRecognizerStateCancelled:{
            self.isInteraction = NO;
            [self.popInteraction cancelInteractiveTransition];
        }
            break;
        case UIGestureRecognizerStateEnded:{
            self.isInteraction = NO;
            if (self.isFinishInteraction) {
                [self.popInteraction finishInteractiveTransition];
            } else {
                [self.popInteraction cancelInteractiveTransition];
            }
        }
            break;
            
        default:
            break;
    }
}

#pragma mark - getter
- (LCPopAnimate *)popAnimate  {
    if (!_popAnimate) {
        _popAnimate = [[LCPopAnimate alloc] init];
    }
    return _popAnimate;
}

- (UIPercentDrivenInteractiveTransition *)popInteraction  {
    if (!_popInteraction) {
        _popInteraction = [[UIPercentDrivenInteractiveTransition alloc] init];
    }
    return _popInteraction;
}

- (UIImageView *)imageView  {
    if (!_imageView) {
        _imageView = [[UIImageView alloc] init];
        _imageView.width = self.view.width - 100;
        _imageView.height = _imageView.width;
        _imageView.centerX = self.view.centerX;;
        _imageView.y = 100;
    }
    return _imageView;
}

- (LCLabel *)descirbeLabel  {
    if (!_descirbeLabel) {
        _descirbeLabel = [[LCLabel alloc] init];
        _descirbeLabel.numberOfLines = 0;
        _descirbeLabel.backgroundColor = [UIColor lightGrayColor];
    }
    return _descirbeLabel;
}
@end
