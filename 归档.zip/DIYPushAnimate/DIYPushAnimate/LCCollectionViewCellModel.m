//
//  LCCollectionViewCellModel.m
//  DIYPushAnimate
//
//  Created by Rochang on 16/9/21.
//  Copyright © 2016年 Rochang. All rights reserved.
//

#import "LCCollectionViewCellModel.h"
#import "MJExtension.h"

@implementation LCCollectionViewCellModel

+ (NSArray *)getLCCollectionViewCellDataSourse {
    // 数据
    NSMutableArray *dataSource = [[NSMutableArray alloc] init];
    for (int i = 1; i < 8; i++) {
        NSString *image = [NSString stringWithFormat:@"%d",i];
        NSString *title = [NSString stringWithFormat:@"小狗%d",i];
        NSString *describe = @"🐔 🐂 🐑 🐵 🐩 🐱 🐍 🐰 🐘 🐯 ~\(≧▽≦)/~ O(∩_∩)O~ (*^__^*) …… O(∩_∩)O~  O(∩_∩)O~ (*^__^*) o(>﹏<)o (⊙v⊙) (ˇˍˇ) ";
        NSDictionary *dict = [[NSDictionary alloc] initWithObjects:@[image, title ,describe] forKeys:@[@"image", @"title", @"describeText"]];
        [dataSource addObject:dict];
    }
    // 模型转换
    return [self mj_objectArrayWithKeyValuesArray:dataSource];
}

@end
