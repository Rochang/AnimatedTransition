//
//  TabBarControllerAnimatedTransitioning.h
//  SlipToChangeTabBarControllerDemo
//
//  Created by Rochang on 16/9/18.
//  Copyright © 2016年 Rochang. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, TabOperationDirection) {
    TabOperationDirectionLeft,
    TabOperationDirectionRight
};

@interface TabBarControllerAnimatedTransitioning : NSObject<UIViewControllerAnimatedTransitioning>

- (instancetype)initWithTabOperationDirection:(TabOperationDirection)direction;

@end
