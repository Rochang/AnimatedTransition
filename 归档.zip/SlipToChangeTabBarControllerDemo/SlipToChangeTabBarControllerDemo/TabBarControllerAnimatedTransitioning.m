//
//  TabBarControllerAnimatedTransitioning.m
//  SlipToChangeTabBarControllerDemo
//
//  Created by Rochang on 16/9/18.
//  Copyright © 2016年 Rochang. All rights reserved.
//

#import "TabBarControllerAnimatedTransitioning.h"

@interface TabBarControllerAnimatedTransitioning ()

@property (assign, nonatomic) TabOperationDirection direction;

@end

@implementation TabBarControllerAnimatedTransitioning

#pragma mark - API
- (instancetype)initWithTabOperationDirection:(TabOperationDirection)direction {
    if (self = [super init]) {
        self.direction = direction;
    }
    return self;
}

// 转场动画的时间
- (NSTimeInterval)transitionDuration:(id<UIViewControllerContextTransitioning>)transitionContext {
    return 0.4;
}

// 设置转场动画
- (void)animateTransition:(id<UIViewControllerContextTransitioning>)transitionContext {
    // 获取fromVc和toVc
    UIView *containerView = [transitionContext containerView];
    UIViewController *toVC = [transitionContext viewControllerForKey:UITransitionContextToViewControllerKey];
    
    // 获取toView和formview的frame
    CGRect toViewFinalFrame = [transitionContext finalFrameForViewController:toVC];
    
    // 设置frame
    if (self.direction == TabOperationDirectionLeft) { // 左滑
        toVC.view.frame = CGRectOffset(toViewFinalFrame, -toViewFinalFrame.size.width, 0);
    } else { // 右滑
        toVC.view.frame = CGRectOffset(toViewFinalFrame, toViewFinalFrame.size.width, 0);
    }
    [containerView addSubview:toVC.view];
    
    // 执行动画
    NSTimeInterval duration = [self transitionDuration:transitionContext];
    [UIView animateWithDuration:duration animations:^{
        toVC.view.frame = toViewFinalFrame;
    } completion:^(BOOL finished) {
        
        BOOL isCancelled = [transitionContext transitionWasCancelled];
        [transitionContext completeTransition:!isCancelled];
    }];
}

@end
