//
//  AppDelegate.m
//  SlipToChangeTabBarControllerDemo
//
//  Created by Rochang on 16/9/18.
//  Copyright © 2016年 Rochang. All rights reserved.
//

#import "AppDelegate.h"
#import "ScrollTabBarController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    ScrollTabBarController *tabBarC = [[ScrollTabBarController alloc] init];
    self.window.rootViewController = tabBarC;
    [self.window makeKeyAndVisible];
    return YES;
}

@end
