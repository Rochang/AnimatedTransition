//
//  ScrollTabBarController.h
//  SlipToChangeTabBarControllerDemo
//
//  Created by Rochang on 16/9/18.
//  Copyright © 2016年 Rochang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScrollTabBarController : UITabBarController

/** 如果UITabBarController的子控制器View添加了可滑动的View,要在可滑动View中添加滑动手势并调用这个方法 */
- (void)handlePanGesture:(UIPanGestureRecognizer *)panGesture;

@end
