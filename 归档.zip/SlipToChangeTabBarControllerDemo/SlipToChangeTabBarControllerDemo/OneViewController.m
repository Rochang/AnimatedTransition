//
//  OneViewController.m
//  SlipToChangeTabBarControllerDemo
//
//  Created by Rochang on 16/9/18.
//  Copyright © 2016年 Rochang. All rights reserved.
//

#import "OneViewController.h"
#import "ScrollTabBarController.h"

@interface OneViewController ()

@end

@implementation OneViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor grayColor];
}

@end
