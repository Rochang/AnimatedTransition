//
//  ScrollTabBarController.m
//  SlipToChangeTabBarControllerDemo
//
//  Created by Rochang on 16/9/18.
//  Copyright © 2016年 Rochang. All rights reserved.
//

#import "ScrollTabBarController.h"
#import "OneViewController.h"
#import "TwoViewController.h"
#import "ThreeViewController.h"
#import "FourViewController.h"
// taBBarController的转场动画
#import "TabBarControllerAnimatedTransitioning.h"

@interface ScrollTabBarController ()<UITabBarControllerDelegate>
/** 是否手势交互 */
@property (assign, nonatomic) BOOL IsInteractiving;
/** 是否完成交互 */
@property (assign, nonatomic) BOOL isFinishInteracion;

/** 手势过渡的完成度 */
@property (strong, nonatomic) UIPercentDrivenInteractiveTransition *interactionTransition;

@end

@implementation ScrollTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.delegate = self;
    [self setupChildViewControllers];
    [self setupTabBarButtons];
    [self addPanGestureToChildViwControllers];
}

- (void)setupChildViewControllers {
    
    OneViewController *oneVc = [[OneViewController alloc] init];
    UINavigationController *firstNav = [[UINavigationController alloc] initWithRootViewController:oneVc];
    oneVc.navigationItem.title = @"滑动切换TabBarController";
    oneVc.navigationItem.title = @"🐱";
    TwoViewController *twoVc = [[TwoViewController alloc] init];
    UINavigationController *secondNav = [[UINavigationController alloc] initWithRootViewController:twoVc];
    twoVc.navigationItem.title = @"🐩";
    ThreeViewController *threeVc = [[ThreeViewController alloc] init];
    UINavigationController *thirdNav = [[UINavigationController alloc] initWithRootViewController:threeVc];
    threeVc.navigationItem.title = @"🐂";
    FourViewController *fourVc = [[FourViewController alloc] init];
    UINavigationController *fourNav = [[UINavigationController alloc] initWithRootViewController:fourVc];
    fourVc.navigationItem.title = @"👃";
    self.viewControllers = @[firstNav, secondNav, thirdNav, fourNav];
}

// 设置TabBarButton
- (void)setupTabBarButtons {
    UIEdgeInsets edge = UIEdgeInsetsMake(6, 0, -6, 0);
    [self setupTabBarButtonsWithIndex:0 image:@"tabbar_mainframe" selectImage:@"tabbar_mainframeHL" imageEdge:edge];
    [self setupTabBarButtonsWithIndex:1 image:@"tabbar_contacts" selectImage:@"tabbar_contactsHL" imageEdge:edge];
    [self setupTabBarButtonsWithIndex:2 image:@"tabbar_discover" selectImage:@"tabbar_discoverHL" imageEdge:edge];
    [self setupTabBarButtonsWithIndex:3 image:@"tabbar_me" selectImage:@"tabbar_meHL" imageEdge:edge];
}

- (void)setupTabBarButtonsWithIndex:(NSUInteger)index image:(NSString *)image selectImage:(NSString *)selectImage imageEdge:(UIEdgeInsets)edge {
    
    UINavigationController *navC = self.childViewControllers[index];
    navC.tabBarItem.image = [[UIImage imageNamed:image] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    navC.tabBarItem.selectedImage = [[UIImage imageNamed:selectImage] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    navC.tabBarItem.imageInsets = edge;
}

/** 给ChildViewContorllers添加Pan手势 */
- (void)addPanGestureToChildViwControllers {
    for (UIViewController *vc in self.childViewControllers) {
        UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePanGesture:)];
        [vc.view addGestureRecognizer:pan];
    }
}

/** 处理pan手势 */
- (void)handlePanGesture:(UIPanGestureRecognizer *)panGesture {
    
    CGFloat translationX = [panGesture translationInView:panGesture.view].x;
    CGFloat translationAbs = translationX > 0 ? translationX : - translationX;
    CGFloat progress = translationAbs / self.view.frame.size.width;
    static CGFloat beginTime;
    switch (panGesture.state) {
        case UIGestureRecognizerStateBegan: {
            beginTime = CACurrentMediaTime();
            self.IsInteractiving = YES;
            if (translationX < 0) { // 左滑,selectIndex + 1
                self.selectedIndex += 1;
            }
            else if (translationX > 0){
                self.selectedIndex -= 1;
            }
            break;
        }
        case UIGestureRecognizerStateChanged: {
            [self.interactionTransition updateInteractiveTransition:progress];
            // 计算pan速度
            CGFloat speen = translationAbs / (CACurrentMediaTime() - beginTime);
            self.isFinishInteracion = (progress > 0.5 || speen > 600);
            break;
        }
        case UIGestureRecognizerStateCancelled:{
            self.IsInteractiving = NO;
            [self.interactionTransition cancelInteractiveTransition];
        }
        case UIGestureRecognizerStateEnded: {
            self.IsInteractiving = NO;
            if (!self.isFinishInteracion) {
                [self.interactionTransition cancelInteractiveTransition];
            } else {
                [self.interactionTransition finishInteractiveTransition];
            }
            break;
        }
        default:
            break;
    }
}

#pragma mark - UITabBarControllerDelegate
// 返回手势过渡的管理对象
- (id<UIViewControllerInteractiveTransitioning>)tabBarController:(UITabBarController *)tabBarController interactionControllerForAnimationController:(id<UIViewControllerAnimatedTransitioning>)animationController {
    return self.IsInteractiving? self.interactionTransition : nil;
}

// 返回转场动画的过渡对象
- (id<UIViewControllerAnimatedTransitioning>)tabBarController:(UITabBarController *)tabBarController animationControllerForTransitionFromViewController:(UIViewController *)fromVC toViewController:(UIViewController *)toVC {
    if (!self.IsInteractiving) {
        return nil;
    }
    NSUInteger fromIndex = [tabBarController.viewControllers indexOfObject:fromVC];
    NSUInteger toIndex = [tabBarController.viewControllers indexOfObject:toVC];
    TabOperationDirection direction = toIndex < fromIndex ? TabOperationDirectionLeft : TabOperationDirectionRight;
    return [[TabBarControllerAnimatedTransitioning alloc] initWithTabOperationDirection:direction];
    }


#pragma mark -  getter
- (UIPercentDrivenInteractiveTransition *)interactionTransition {
    if (!_interactionTransition) {
        _interactionTransition = [[UIPercentDrivenInteractiveTransition alloc] init];
    }
    return _interactionTransition;
}

@end
